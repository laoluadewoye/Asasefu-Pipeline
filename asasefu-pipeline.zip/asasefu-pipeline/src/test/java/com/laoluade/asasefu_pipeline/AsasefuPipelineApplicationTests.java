package com.laoluade.asasefu_pipeline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsasefuPipelineApplicationTests {

	@Test
	void contextLoads() {
	}

}
