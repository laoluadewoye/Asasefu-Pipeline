package com.laoluade.asasefu_pipeline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsasefuPipelineApplication {

	public static void main(String[] args) {
		SpringApplication.run(AsasefuPipelineApplication.class, args);
	}

}
